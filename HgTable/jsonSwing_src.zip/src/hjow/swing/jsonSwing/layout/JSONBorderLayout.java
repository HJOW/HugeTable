/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.swing.jsonSwing.layout;

import java.awt.BorderLayout;

import com.google.gson.JsonObject;

import hjow.swing.jsonSwing.JSONCore;

/**
 * <p>JSON 형태로 BorderLayout 과 호환되는 컴포넌트 객체를 만드는 데 사용됩니다.</p>
 * 
 * @author HJOWs
 *
 */
public class JSONBorderLayout extends BorderLayout implements JSONLayout
{
	private static final long serialVersionUID = 5574754874469150143L;
	public static final String JSON_KEYWORD = "BORDER_LAYOUT";
	@Override
	public String getJsonKeyword()
	{
		return JSON_KEYWORD;
	}
	public JSONBorderLayout()
	{
		
	}
	
	public JSONBorderLayout(JsonObject jsonObj) throws Exception
	{
		JSONCore.installProperties(this, jsonObj);
	}
}
