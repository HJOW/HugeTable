/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.swing.jsonSwing;

import java.awt.BorderLayout;
import java.awt.Component;
import java.lang.reflect.Method;
import java.security.InvalidParameterException;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import javax.script.ScriptException;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

import hjow.swing.jsonSwing.components.JSONButton;
import hjow.swing.jsonSwing.components.JSONComboBox;
import hjow.swing.jsonSwing.components.JSONComponent;
import hjow.swing.jsonSwing.components.JSONLabel;
import hjow.swing.jsonSwing.components.JSONPanel;
import hjow.swing.jsonSwing.components.JSONTextField;
import hjow.swing.jsonSwing.event.JSONActionListener;
import hjow.swing.jsonSwing.event.JSONEvent;
import hjow.swing.jsonSwing.event.JSONItemListener;
import hjow.swing.jsonSwing.layout.JSONBorderLayout;
import hjow.swing.jsonSwing.layout.JSONFlowLayout;
import hjow.swing.jsonSwing.layout.JSONGridLayout;
import hjow.swing.jsonSwing.window.JSONDialog;
import hjow.swing.jsonSwing.window.JSONFrame;

/**
 * <p>JSONSwing 사용을 위한 공통 매커니즘을 구현하는 클래스입니다. 대부분 정적 메소드들로 이루어져 있습니다.</p>
 * 
 * @author HJOW
 *
 */
public class JSONCore
{
	protected static List<JSONSwingObject> componentSamples = new Vector<JSONSwingObject>();
	protected static JsonParser parser = new JsonParser();
	protected static javax.script.ScriptEngineManager engineManager = new javax.script.ScriptEngineManager();
	protected static Map<String, javax.script.ScriptEngine> engines = new Hashtable<String, javax.script.ScriptEngine>();
	protected static boolean sampleIsPrepared = false;
	protected static boolean anotherLanguagePrepared = false;
	
	static
	{
		init();
	}
	
	/**
	 * <p>JSONSwing 을 사용하기 위한 준비 작업을 합니다.</p>
	 * 
	 */
	public static void init()
	{
		if(! sampleIsPrepared) prepareSamples();
		
		javax.script.ScriptEngine javaScriptEngine = engines.get("JavaScript");
		if(javaScriptEngine == null) javaScriptEngine = engineManager.getEngineByName("JavaScript");
		
		engines.put("JavaScript", javaScriptEngine);
		engines.put("javascript", javaScriptEngine);
		engines.put("JS", javaScriptEngine);
		engines.put("js", javaScriptEngine);
		
		if(! anotherLanguagePrepared) prepareLanguages();
	}
	
	/**
	 * <p>샘플들을 준비합니다.</p>
	 * 
	 */
	protected static void prepareSamples()
	{
		componentSamples.add(new JSONFrame());
		componentSamples.add(new JSONDialog());
		componentSamples.add(new JSONPanel());
		componentSamples.add(new JSONLabel());
		componentSamples.add(new JSONButton());
		componentSamples.add(new JSONTextField());
		componentSamples.add(new JSONComboBox());
		componentSamples.add(new JSONBorderLayout());
		componentSamples.add(new JSONFlowLayout());
		componentSamples.add(new JSONGridLayout());
		componentSamples.add(new JSONActionListener());
		componentSamples.add(new JSONItemListener());
		
		sampleIsPrepared = true;
	}
	
	/**
	 * <p>샘플을 추가합니다.</p>
	 * 
	 * @param jsonSwingObj : 샘플 객체
	 */
	public static void addSample(JSONSwingObject jsonSwingObj)
	{
		componentSamples.add(jsonSwingObj);
	}
	
	/**
	 * <p>다른 언어에 대한 엔진들을 준비합니다.</p>
	 * 
	 */
	protected static void prepareLanguages()
	{
		List<javax.script.ScriptEngineFactory> engineFactories = engineManager.getEngineFactories();
		for(javax.script.ScriptEngineFactory fac : engineFactories)
		{
			try
			{
				String name = fac.getLanguageName();
				if(name.equalsIgnoreCase("javascript") || name.equalsIgnoreCase("js") || name.equalsIgnoreCase("nashorn")) continue;
				engines.put(name, fac.getScriptEngine());
			}
			catch(Throwable e)
			{
				collectThrows(e);
			}
		}
		
		anotherLanguagePrepared = true;
	}
	
	/**
	 * <p>스크립트 엔진으로 스크립트를 실행합니다.</p>
	 * 
	 * @param scripts : 실행할 스크립트
	 * @return 실행 결과
	 * @throws ScriptException
	 */
	public static Object eval(String scripts) throws ScriptException
	{
		return engines.get("JavaScript").eval(scripts);
	}
	
	/**
	 * <p>스크립트 엔진으로 스크립트를 실행합니다.</p>
	 * 
	 * @param lang : 실행할 스크립트의 언어
	 * @param scripts : 실행할 스크립트
	 * @return 실행 결과
	 * @throws ScriptException
	 */
	public static Object eval(String lang, String scripts) throws ScriptException
	{
		if(JSONUtil.isEmpty(lang)) return engines.get(lang).eval(scripts);
		else return eval(scripts);
	}
	
	/**
	 * <p>스크립트 엔진에서 사용할 수 있도록 객체를 넣습니다.</p>
	 * 
	 * @param key : 사용할 변수 이름
	 * @param obj : 넣을 객체
	 */
	public static void putObject(String key, Object obj)
	{
		engines.get("JavaScript").put(key, obj);
	}
	
	/**
	 * <p>스크립트 엔진에서 사용할 수 있도록 객체를 넣습니다.</p>
	 * 
	 * @param lang :  스크립트 언어
	 * @param key : 사용할 변수 이름
	 * @param obj : 넣을 객체
	 */
	public static void putObject(String lang, String key, Object obj)
	{
		if(JSONUtil.isEmpty(lang)) engines.get(lang).put(key, obj);
		else putObject(key, obj);
	}
	
	/**
	 * <p>새 컴포넌트를 생성합니다.</p>
	 * 
	 * @param json : JSON 형태의 문자열
	 * @return JSON 컴포넌트
	 * @throws Exception
	 */
	public static JSONSwingObject createComponent(String json) throws Exception
	{
		return createComponent(parser.parse(json).getAsJsonObject());
	}
	
	/**
	 * <p>새 컴포넌트를 생성합니다.</p>
	 * 
	 * @param jsonObj : JSON 객체 (GSON 라이브러리에서 제공하는 JsonObject 타입)
	 * @return JSON 컴포넌트
	 * @throws Exception
	 */
	public static JSONSwingObject createComponent(JsonObject jsonObj) throws Exception
	{
		JsonElement keywordElement = jsonObj.get("type");
		String keyword = keywordElement.getAsString();
		for(int i=0; i<componentSamples.size(); i++)
		{
			if(componentSamples.get(i).getJsonKeyword().equals(keyword))
			{
				return (JSONSwingObject) componentSamples.get(i).getClass().getConstructor(JsonObject.class).newInstance(jsonObj);
			}
		}
		return null;
	}
	
	/**
	 * <p>컴포넌트에 속성들을 지정합니다.</p>
	 * 
	 * @param comp : 컴포넌트
	 * @param json : 속성이 지정된 JSON 형식 문자열
	 * @return 오류 메시지들 (오류가 없었다면 빈 문자열 반환)
	 */
	public static String installProperties(JSONSwingObject comp, String json)
	{
		return installProperties(comp, parser.parse(json).getAsJsonObject());
	}
	
	/**
	 * <p>컴포넌트에 속성들을 지정합니다.</p>
	 * 
	 * @param comp : 컴포넌트
	 * @param jsonObj : 속성이 지정된 JSON 객체
	 * @return 오류 메시지들 (오류가 없었다면 빈 문자열 반환)
	 */
	public static String installProperties(JSONSwingObject comp, JsonObject jsonObj)
	{
		StringBuffer errorMsg = new StringBuffer("");
		Set<Entry<String, JsonElement>> entry = jsonObj.entrySet();
		for(Entry<String, JsonElement> entryElement :  entry)
		{
			String key = entryElement.getKey();
			JsonElement element = entryElement.getValue();
			
			if(element.isJsonNull())
			{
				
			}
			else if(element.isJsonPrimitive()) // 기본형 값인 경우 : 매개 변수가 기본형 타입 하나인 setter 메소드 호출, 기본형 타입 종류에 따라 분기해 적용함
			{
				try
				{
					JsonPrimitive prim = element.getAsJsonPrimitive();
					if(prim.isBoolean())
					{
						comp.getClass().getMethod(JSONUtil.translateToCamel(key, "set"), Boolean.class).invoke(comp, new Boolean(prim.getAsBoolean()));
					}
					else if(prim.isNumber()) // 숫자인 경우 : 정수 / 실수형인지 판별해 적용
					{
						int val1 = 0;
						double val2 = 0.0;
						boolean checkFinished = false;
						boolean isInteger = false;
						
						try
						{
							val1 = prim.getAsInt();
						}
						catch(Exception e)
						{
							checkFinished = true;
							isInteger = false;
						}
						
						try
						{
							val2 = prim.getAsDouble();
						}
						catch(Exception e)
						{
							checkFinished = true;
							isInteger = true;
						}
						
						if(! checkFinished)
						{
							if(val1 + 0.0 == val2) isInteger = true;
							else isInteger = false;
						}
						
						if(isInteger) comp.getClass().getMethod(JSONUtil.translateToCamel(key, "set"), Integer.class).invoke(comp, new Integer(prim.getAsInt()));
						else comp.getClass().getMethod(JSONUtil.translateToCamel(key, "set"), Double.class).invoke(comp, new Double(prim.getAsDouble()));
					}
					else if(prim.isString()) // 문자열인 경우
					{
						String stringVal = prim.getAsString();
						boolean isAbsolutelyString = false;
						if(stringVal.startsWith("<STRING>") && stringVal.endsWith("</>"))
						{
							isAbsolutelyString = true;
							stringVal = stringVal.substring(stringVal.indexOf("<STRING>") + new String("<STRING>").length(), stringVal.indexOf("</>"));
						}
						if(JSONUtil.isBoolean(stringVal) && (! isAbsolutelyString))
						{
							comp.getClass().getMethod(JSONUtil.translateToCamel(key, "set"), Boolean.class).invoke(comp, new Boolean(JSONUtil.parseBoolean(prim.getAsString())));
						}
						else comp.getClass().getMethod(JSONUtil.translateToCamel(key, "set"), String.class).invoke(comp, prim.getAsString());
					}
				}
				catch(Exception e)
				{
					errorMsg = errorMsg.append("EXCEPTION : ").append(e.getMessage()).append("\n");
					for(StackTraceElement stk : e.getStackTrace())
					{
						errorMsg = errorMsg.append("   from ").append(stk.toString()).append("\n");
					}
				}
			}
			else if(element.isJsonObject()) // JSON 객체인 경우
			{
				try
				{
					if(key.toLowerCase().endsWith("listener")) // 리스너인 경우 : adder 메소드 호출
					{
						key = JSONUtil.translateToCamel(key, "add");
						JSONEvent insideComp = (JSONEvent) createComponent(element.getAsJsonObject());
						comp.getClass().getMethod(JSONUtil.translateToCamel(key, "add"), insideComp.getClass()).invoke(comp, insideComp);
					}
					else
					{
						String propertyType = "set";
						if(key.toLowerCase().startsWith("add")) propertyType = "add";
						JSONSwingObject insideComp = createComponent(element.getAsJsonObject());
						
						if(insideComp == null) // 컴포넌트 정의 JSON 이 아닌 경우 : 여러 매개 변수의 setter 메소드 호출
						{
							JsonObject paramObj = element.getAsJsonObject();
							Set<Map.Entry<String,JsonElement>> paramEntries = paramObj.entrySet();
							List<Map.Entry<String,JsonElement>> paramEntryList = new Vector<Map.Entry<String,JsonElement>>();
							paramEntryList.addAll(paramEntries);
							
							Object[] params = new Object[paramEntryList.size()];
							Class<?>[] paramTypes = new Class<?>[params.length];
							for(int i=0; i<paramEntryList.size(); i++)
							{
								Entry<String, JsonElement> paramEntry = paramEntryList.get(i);
								JsonElement paramVal = paramEntry.getValue();
								if(paramVal.isJsonPrimitive())
								{
									JsonPrimitive paramPrim = paramVal.getAsJsonPrimitive();
									if(paramPrim.isBoolean())
									{
										params[i] = new Boolean(paramPrim.getAsBoolean());
										paramTypes[i] = Boolean.class;
									}
									if(paramPrim.isNumber())
									{
										int val1 = 0;
										double val2 = 0.0;
										boolean checkFinished = false;
										boolean isInteger = false;
										
										try
										{
											val1 = paramPrim.getAsInt();
										}
										catch(Exception e)
										{
											checkFinished = true;
											isInteger = false;
										}
										
										try
										{
											val2 = paramPrim.getAsDouble();
										}
										catch(Exception e)
										{
											checkFinished = true;
											isInteger = true;
										}
										
										if(! checkFinished)
										{
											if(val1 + 0.0 == val2) isInteger = true;
											else isInteger = false;
										}
										
										if(isInteger)
										{
											params[i] = new Integer(paramPrim.getAsInt());
											paramTypes[i] = Integer.class;
										}
										else
										{
											params[i] = new Double(paramPrim.getAsDouble());
											paramTypes[i] = Double.class;
										}
									}
									else if(paramPrim.isString())
									{
										params[i] = paramPrim.getAsString();
										paramTypes[i] = String.class;
									}
								}
								else if(paramVal.isJsonObject())
								{
									params[i] = createComponent(paramVal.getAsJsonObject());
									paramTypes[i] = params[i].getClass();
								}
							}
							Method method = comp.getClass().getMethod(JSONUtil.translateToCamel(key, "set"), paramTypes);
							method.invoke(comp, params);
						}
						else // 컴포넌트 정의 JSON 인 경우 
						{
							comp.getClass().getMethod(JSONUtil.translateToCamel(key, propertyType), insideComp.getClass()).invoke(comp, insideComp);
						}
					}
				}
				catch(Exception e)
				{
					errorMsg = errorMsg.append("EXCEPTION : ").append(e.getMessage()).append("\n");
					for(StackTraceElement stk : e.getStackTrace())
					{
						errorMsg = errorMsg.append("   from ").append(stk.toString()).append("\n");
					}
				}
			}
			else if(element.isJsonArray()) // JSON 배열인 경우
			{
				try
				{
					if(key.equalsIgnoreCase("add")) // adder 처리
					{
						JsonArray array = element.getAsJsonArray();
						boolean installEnded = false;
						if(array.size() == 2)  // adder 이면서 원소가 2개인 경우
						{
							if(array.get(0).isJsonObject() && array.get(1).isJsonPrimitive()) // BorderLayout 을 사용하는 컴포넌트에 컴포넌트를 붙이는 경우
							{
								JSONComponent insideComp = (JSONComponent) createComponent(array.get(0).getAsJsonObject());
								JsonPrimitive secondVal = array.get(1).getAsJsonPrimitive();
								
								if(secondVal.isNumber())
								{
									comp.getClass().getMethod("add", Component.class, Integer.class).invoke(comp, insideComp.getComponent(), new Integer(secondVal.getAsInt()));
								}
								else if(secondVal.isString())
								{
									String borderLayoutKeyword = secondVal.getAsString().trim().toLowerCase();
									if(borderLayoutKeyword.equals("center"))
									{
										comp.getClass().getMethod("add", Component.class, Integer.class).invoke(comp, insideComp.getComponent(), new Integer(BorderLayout.CENTER));
									}
									else if(borderLayoutKeyword.equals("south") || borderLayoutKeyword.equals("bottom") || borderLayoutKeyword.equals("down"))
									{
										comp.getClass().getMethod("add", Component.class, Integer.class).invoke(comp, insideComp.getComponent(), new Integer(BorderLayout.SOUTH));
									}
									else if(borderLayoutKeyword.equals("north") || borderLayoutKeyword.equals("top") || borderLayoutKeyword.equals("up"))
									{
										comp.getClass().getMethod("add", Component.class, Integer.class).invoke(comp, insideComp.getComponent(), new Integer(BorderLayout.NORTH));
									}
									else if(borderLayoutKeyword.equals("east") || borderLayoutKeyword.equals("right"))
									{
										comp.getClass().getMethod("add", Component.class, Integer.class).invoke(comp, insideComp.getComponent(), new Integer(BorderLayout.EAST));
									}
									else if(borderLayoutKeyword.equals("west") || borderLayoutKeyword.equals("left"))
									{
										comp.getClass().getMethod("add", Component.class, Integer.class).invoke(comp, insideComp.getComponent(), new Integer(BorderLayout.WEST));
									}
									else throw new InvalidParameterException();
								}
								else throw new InvalidParameterException();
								installEnded = true;
							}
						}
						if(! installEnded) // 그 외의 경우
						{
							for(JsonElement elementInsides : array)
							{
								JSONComponent insideComp = (JSONComponent) createComponent(elementInsides.getAsJsonObject());
								comp.getClass().getMethod("add", Component.class).invoke(comp, insideComp.getComponent());
							}
						}
					}
				}
				catch(Exception e)
				{
					errorMsg = errorMsg.append("EXCEPTION : ").append(e.getMessage()).append("\n");
					for(StackTraceElement stk : e.getStackTrace())
					{
						errorMsg = errorMsg.append("   from ").append(stk.toString()).append("\n");
					}
				}
			}
		}
		return errorMsg.toString();
	}
	
	/**
	 * <p>예외 및 오류 내용을 수집합니다.</p>
	 * 
	 * @param t : 예외, 혹은 오류 객체
	 */
	public static void collectThrows(Throwable t)
	{
		
	}
}
