/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.swing.jsonSwing;

import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import com.google.gson.JsonNull;

/**
 * <p>코드 작성에 도움이 되는 정적 메소드들을 모아 놓은 클래스입니다.</p>
 * 
 * @author HJOW
 *
 */
public class JSONUtil
{
	/**
	 * <p>해당 객체가 비어 있는지 여부를 검사합니다.</p>
	 * 
	 * @param ob : 검사할 객체
	 * @return 비어 있는지 여부
	 */
	public static boolean isEmpty(Object ob)
	{
		if(ob == null)
		{
			return true;
		}
		else if(ob instanceof JsonNull)
		{
			return true;
		}
		else if(ob instanceof String)
		{
			if(((String) ob).trim().equals("")) return true;
		}
		else if(ob instanceof List<?>)
		{
			return ((List<?>) ob).isEmpty();
		}
		else if(ob instanceof Map<?, ?>)
		{
			return ((Map<?, ?>) ob).isEmpty();
		}
		else
		{
			return isEmpty(String.valueOf(ob));
		}
		return false;
	}
	
	/**
	 * <p>낙타식 표기법으로 해당 이름을 번역해 반환합니다.</p>
	 * 
	 * @param name : 번역할 이름
	 * @return 번역 결과
	 */
	public static String translateToCamel(String name)
	{
		return translateToCamel(name, null);
	}
	
	/**
	 * <p>낙타식 표기법으로 해당 이름을 번역해 반환합니다.</p>
	 * 
	 * @param name : 번역할 이름
	 * @param prefix : 앞에 붙일 접두사
	 * @return 번역 결과
	 */
	public static String translateToCamel(String name, String prefix)
	{
		StringBuffer result = new StringBuffer("");
		StringTokenizer tokenizer = new StringTokenizer(name, "_");
		while(tokenizer.hasMoreTokens())
		{
			String element = new String(tokenizer.nextToken());
			String firstChar = element.substring(0, 1);
			String anothers = element.substring(1);
			firstChar = firstChar.toUpperCase();
			result = result.append(firstChar + anothers);
		}
		
		if(isEmpty(prefix))
		{
			result.setCharAt(0, result.substring(0, 1).toLowerCase().toCharArray()[0]);
		}
		else result = new StringBuffer(prefix.toLowerCase()).append(result);
		return result.toString();
	}
	
	/**
	 * <p>어떤 문자열이 숫자형 값으로 번역이 가능한지 여부를 반환합니다.</p>
	 * 
	 * @param val : 검사할 문자열
	 * @return 검사 결과
	 */
	public static boolean isNumber(String val)
	{
		return isInteger(val) || isFloat(val);
	}
	
	/**
	 * <p>어떤 문자열이 정수형 값으로 번역이 가능한지 여부를 반환합니다.</p>
	 * 
	 * @param val : 검사할 문자열
	 * @return 검사 결과
	 */
	public static boolean isInteger(String val)
	{
		try
		{
			Integer.parseInt(val);
			return true;
		}
		catch(Exception e)
		{
			
		}
		return false;
	}
	
	/**
	 * <p>어떤 문자열이 실수형 값으로 번역이 가능한지 여부를 반환합니다.</p>
	 * 
	 * @param val : 검사할 문자열
	 * @return 검사 결과
	 */
	public static boolean isFloat(String val)
	{
		try
		{
			Double.parseDouble(val);
			return true;
		}
		catch(Exception e)
		{
			
		}
		return false;
	}
	
	/**
	 * <p>어떤 문자열이 논리형 값으로 번역이 가능한지 여부를 반환합니다.</p>
	 * 
	 * @param val : 검사할 문자열
	 * @return 검사 결과
	 */
	public static boolean isBoolean(String val)
	{
		String target = val.trim();
		target = target.toLowerCase();
		if(target.equals("true") || target.equals("false") || target.equals("t") || target.equals("f")
				 || target.equals("y") || target.equals("n")
				 || target.equals("yes") || target.equals("no")
				 || target.equals("예") || target.equals("아니오")) return true;
		return false;
	}
	
	/**
	 * <p>어떤 문자열을 논리값으로 변환합니다. true, false, y, n, yes, no 를 인식하며, 대소문자를 가리지 않습니다.</p>
	 * 
	 * @param val : 대상 문자열
	 * @return 변환된 논리값
	 * @throws IllegalArgumentException
	 */
	public static boolean parseBoolean(String val) throws IllegalArgumentException
	{
		if(! isBoolean(val)) throw new IllegalArgumentException();
		String target = val.trim();
		target = target.toLowerCase();
		if(target.equals("true") || target.equals("t") || target.equals("y") || target.equals("yes") || target.equals("예")) return true;
		return false;
	}
}
