/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.swing.jsonSwing.event;

import java.awt.Window;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import hjow.swing.jsonSwing.JSONCore;

/**
 * <p>AWT/Swing 의 WindowListener 에 대응하는 이벤트 객체입니다.</p>
 * <p>주로 버튼 클릭, 텍스트 필드에 대한 엔터 처리 등을 다룹니다.</p>
 * 
 * @author HJOW
 *
 */
public class JSONWindowListener extends JSONEvent implements WindowListener
{
	@Override
	public String getJsonKeyword()
	{
		return "WINDOW_LISTENER";
	}
	
	/**
	 * <p>이벤트 발생 시 실행되는 스크립트를 반환합니다. 다음과 같은 변수 이름으로 이벤트의 내용에 액세스할 수 있습니다.</p>
	 * <p>
	 * 	  <li>_source	: 이벤트를 발생시킨 컴포넌트 객체</li>
	 *    <li>_type	: 이벤트 종류</li>
	 *    <li>_selectable	: 이벤트 발생의 근본 객체</li>
	 *    <li>_item	: 이벤트의 영향을 받은 아이템 객체</li>
	 *    <li>_event	: 이벤트 객체</li>
	 * </p>
	 * 
	 * @return 이벤트 스크립트
	 */
	@Override
	public String getScripts()
	{
		return super.getScripts();
	}
	
	/**
	 * <p>이벤트 발생 시 실행시킬 스크립트를 지정합니다. 다음과 같은 변수 이름으로 이벤트의 내용에 액세스할 수 있습니다.</p>
	 * <p>
	 * 	  <li>_source	: 이벤트를 발생시킨 컴포넌트 객체</li>
	 *    <li>_type	: 이벤트 종류</li>
	 *    <li>_selectable	: 이벤트 발생의 근본 객체</li>
	 *    <li>_item	: 이벤트의 영향을 받은 아이템 객체</li>
	 *    <li>_event	: 이벤트 객체</li>
	 * </p>
	 * 
	 * @param scripts : 이벤트 스크립트
	 */
	@Override
	public void setScripts(String scripts)
	{
		super.setScripts(scripts);
	}


	@Override
	public void windowOpened(WindowEvent e)
	{
		Object source = e.getSource();
		Window window = e.getWindow();
		JSONCore.putObject(language, "_source", source);
		JSONCore.putObject(language, "_window", window);
		JSONCore.putObject(language, "_type", "windowOpened");
		JSONCore.putObject(language, "_event", e);
		run();
	}


	@Override
	public void windowClosing(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowClosed(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowIconified(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowDeiconified(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowActivated(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowDeactivated(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}
}
