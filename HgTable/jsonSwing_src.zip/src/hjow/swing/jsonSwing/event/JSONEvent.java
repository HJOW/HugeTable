/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.swing.jsonSwing.event;

import javax.script.ScriptException;

import hjow.swing.jsonSwing.JSONCore;
import hjow.swing.jsonSwing.JSONSwingObject;

/**
 * <p>모든 JSON 이벤트 클래스들은 이 인터페이스를 구현합니다.</p>
 * 
 * @author HJOW
 *
 */
public abstract class JSONEvent implements JSONSwingObject, Runnable
{
	protected String scripts = "";
	protected String language = "";
	
	@Override
	public String getJsonKeyword()
	{
		return "ACTION_LISTENER";
	}

	@Override
	public void run()
	{
		try
		{
			JSONCore.eval(getScript());
		}
		catch (ScriptException e)
		{
			JSONCore.collectThrows(e);
		}
	}

	/**
	 * <p>이벤트 발생 시 실행할 스크립트를 반환합니다.</p>
	 * 
	 * @return 스크립트
	 */
	public String getScript()
	{
		return scripts;
	}

	/**
	 * <p>이벤트 발생 시 실행되는 스크립트를 반환합니다.</p>
	 * 
	 * @return 이벤트 스크립트
	 */
	public String getScripts()
	{
		return scripts;
	}

	/**
	 * <p>이벤트 발생 시 실행시킬 스크립트를 지정합니다.</p>
	 * 
	 * @param scripts : 이벤트 스크립트
	 */
	public void setScripts(String scripts)
	{
		this.scripts = scripts;
	}

	/**
	 * <p>이벤트 발생 시 실행할 스크립트의 언어 이름을 반환합니다.</p>
	 * 
	 * @return 스크립트 언어 이름
	 */
	public String getLanguage()
	{
		return language;
	}

	/**
	 * <p>이벤트 발생 시 실행할 스크립트의 언어를 지정합니다.</p>
	 * 
	 * @param language : 스크립트 언어 이름
	 */
	public void setLanguage(String language)
	{
		this.language = language;
	}
}
