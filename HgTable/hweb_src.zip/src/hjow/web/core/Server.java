/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.web.core;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import hjow.web.content.PageContent;
import hjow.web.session.Session;

/**
 * <p>웹 서버를 운영할 수 있는 서버 객체입니다. 객체 생성 후 init(80) 함수를 호출해 서버를 실행합니다.</p>
 * 
 * @author HJOW
 *
 */
public class Server
{
	protected ServerSocket serverSocket;
	protected Acceptor acceptor; 
	protected Cleaner cleaner;
	protected List<ClientUnit> clients = new Vector<ClientUnit>();
	protected List<Session> sessions = new Vector<Session>();
	protected PageContent pageContent;
	protected static transient PrintStream std = System.out;
	protected long timeout = 1800000;
	protected Server self = this;
	
	/**
	 * <p>서버 객체를 생성합니다. 서버가 실행되지는 않습니다.</p>
	 * 
	 */
	public Server()
	{
		
	}
	
	/**
	 * <p>80 포트로 서버를 실행합니다.</p>
	 * 
	 * @throws IOException
	 */
	public void init() throws IOException
	{
		init(80);
	}
	
	/**
	 * <p>서버를 실행합니다.</p>
	 * 
	 * @param port : 포트 번호
	 * @throws IOException
	 */
	public void init(int port) throws IOException
	{
		self = this;
		serverSocket = new ServerSocket(port);
		acceptor = new Acceptor();
		cleaner = new Cleaner();
		cleaner.start();
		acceptor.start();
	}
	
	/**
	 * <p>서버를 끕니다.</p>
	 * 
	 */
	public void close()
	{
		for(ClientUnit client : clients)
		{
			client.close();
		}
		clients.clear();
		acceptor.stop();
		if(pageContent != null) pageContent.close();
		pageContent = null;
		acceptor = null;
		cleaner.stop();
		cleaner = null;
		try
		{
			serverSocket.close();
		}
		catch(Throwable t)
		{
			
		}
		serverSocket = null;
		self = null;
	}
	
	/**
	 * <p>소켓에 맞는 세션을 반환합니다.</p>
	 * 
	 * @param socket : 접속된 소켓
	 * @return 세션
	 */
	public Session getSession(Socket socket)
	{
		for(Session s : sessions)
		{
			if(s.getIp().equals(socket.getInetAddress().toString()))
			{
				return s;
			}
		}
		return null;
	}
	
	/**
	 * <p>새 세션을 만들어 반환합니다.</p>
	 * 
	 * @param socket : 접속된 소켓
	 * @return 세션
	 */
	public Session newSession(Socket socket)
	{
		Session session = new Session();
		session.setIp(socket.getInetAddress().toString());
		session.setDate(new Date(System.currentTimeMillis()));
		return session;
	}
	
	/**
	 * <p>외부 사용자의 접속을 받는 쓰레드를 운영하기 위한 클래스입니다.</p>
	 * 
	 * @author HJOW
	 *
	 */
	class Acceptor extends DefaultThread
	{
		@Override
		public void onThread()
		{
			try
			{
				Socket accept = serverSocket.accept();
				ClientUnit newClient = new ClientUnit(self, accept, pageContent);
				
				String ip = accept.getInetAddress().toString();
				Session session = null;
				
				for(Session s : sessions)
				{
					if(s.getIp().equals(ip))
					{
						session = s;
						break;
					}
				}
				
				if(session == null) session = new Session();
				session.setIp(ip);
				session.setDate(new Date(System.currentTimeMillis()));
				newClient.setSession(session);
				clients.add(newClient);
			}
			catch(Throwable t)
			{
				t.printStackTrace(std);
			}
		}
	}
	/**
	 * <p>닫힌 접속들을 찾아내 정리하기 위한 클래스입니다.</p>
	 * 
	 * @author HJOW
	 *
	 */
	class Cleaner extends DefaultThread
	{
		int i;
		@Override
		public void onThread()
		{
			try
			{
				i = 0;
				while(i < clients.size())
				{
					if(! (clients.get(i).isAlive()))
					{
						clients.get(i).close();
						clients.remove(i);
						i = 0;
						continue;
					}
					i++;
				}
				i = 0;
				while(i < sessions.size())
				{
					if(! (sessions.get(i).isAlive()))
					{
						sessions.get(i).close();
						sessions.remove(i);
						i = 0;
						continue;
					}
					else if(sessions.get(i).needInvalidate())
					{
						sessions.get(i).invalidate();
					}
					i++;
				}
			}
			catch(Throwable t)
			{
				t.printStackTrace(std);
			}
		}
	}
	public ServerSocket getServerSocket()
	{
		return serverSocket;
	}

	public void setServerSocket(ServerSocket serverSocket)
	{
		this.serverSocket = serverSocket;
	}

	public Acceptor getAcceptor()
	{
		return acceptor;
	}

	public void setAcceptor(Acceptor acceptor)
	{
		this.acceptor = acceptor;
	}

	public Cleaner getCleaner()
	{
		return cleaner;
	}

	public void setCleaner(Cleaner cleaner)
	{
		this.cleaner = cleaner;
	}
	
	public ClientUnit getClient(int idx)
	{
		return clients.get(idx);
	}

	public List<ClientUnit> getClients()
	{
		return clients;
	}

	public void setClients(List<ClientUnit> clients)
	{
		this.clients = clients;
	}

	public PageContent getPageContent()
	{
		return pageContent;
	}

	public void setPageContent(PageContent pageContent)
	{
		this.pageContent = pageContent;
		this.pageContent.initialize();
	}

	public List<Session> getSessions()
	{
		return sessions;
	}

	public void setSessions(List<Session> sessions)
	{
		this.sessions = sessions;
	}

	public long getTimeout()
	{
		return timeout;
	}

	public void setTimeout(long timeout)
	{
		this.timeout = timeout;
	}
}
