/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.web.core;

public class DefaultThread implements Runnable
{
	protected boolean threadSwitch = true;
	protected long gap = 20;
	protected int randomGap = 10;
	protected long delay = 0;
	protected long delayUnit = 1;
	protected boolean paused = false;
	protected Thread thread;
	
	public void start()
	{
		threadSwitch = true;
		thread = new Thread(this);
		thread.start();
	}
	
	public void stop()
	{
		threadSwitch = false;
		try
		{
			if(thread != null) thread.interrupt();
		}
		catch(Throwable t)
		{
			
		}
		thread = null;
	}
	
	public void interrupt()
	{
		thread.interrupt();
	}
	
	public void pause()
	{
		paused = true;
	}
	
	public void resume()
	{
		paused = false;
	}
	
	public void onThread()
	{
		
	}
	
	private void onThreadWithThrowing() throws Throwable
	{
		onThread();
	}
	
	
	@Override
	public void run()
	{
		while(threadSwitch)
		{
			try
			{
				if(! paused) onThreadWithThrowing();
				delay = delay - delayUnit;
				if(delay < 0) delay = 0;
			}
			catch(Throwable t)
			{
				delay = delay + delayUnit;
			}
			try
			{
				Thread.sleep(gap + (int)(Math.random() * randomGap) + delay);
			}
			catch(Throwable t)
			{
				
			}
		}
	}
}
