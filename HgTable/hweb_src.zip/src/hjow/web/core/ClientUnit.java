/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.web.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Date;

import hjow.web.content.PageContent;
import hjow.web.session.Session;

/**
 * <p>서버가 운영 중일 때 외부 사용자가 접속하면 이 클래스 객체가 생성됩니다.</p>
 * 
 * @author HJOW
 *
 */
public class ClientUnit
{
	protected Socket socket;
	protected DataOutputStream outputStream;
	protected DataInputStream inputStream;
	protected Receiver receiver;
	protected String prefix = "HTTP/1.1 200 OK \nContent-Type: text/html; charset=UTF-8 \n\n";
	protected transient PageContent content;
	protected int bufferSize = 65536;
	protected transient Session session;
	protected transient Server server;
	
	/**
	 * <p>이 생성자는 서버 객체에 의해 호출됩니다.</p>
	 * 
	 * @param server : 서버 객체
	 * @param socket : 접속 승인된 소켓 객체 (java.net.ServerSocket 의 accept() 메소드로 반환)
	 * @param pageContent : 접속 URL에 따라 페이지를 그리는 컨텐츠 객체
	 * @throws IOException
	 */
	public ClientUnit(Server server, Socket socket, PageContent pageContent) throws IOException
	{
		if(socket == null) throw new NullPointerException();
		if(socket.isClosed()) throw new IOException("Connection is closed before.");
		this.socket = socket;
		this.content = pageContent;
		outputStream = new DataOutputStream(socket.getOutputStream());
		inputStream = new DataInputStream(socket.getInputStream());
		receiver = new Receiver();
		receiver.start();
	}
	
	/**
	 * <p>사용자의 접속이 아직 유효한지 여부를 반환합니다.</p>
	 * 
	 * @return 접속 유지 상태
	 */
	public boolean isAlive()
	{
		return socket != null && (! socket.isClosed());
	}
	
	public void setPrefix(String prefix)
	{
		this.prefix = prefix;
	}
	
	/**
	 * <p>사용자와의 접속을 끊습니다.</p>
	 * 
	 */
	public void close()
	{
		try
		{
			receiver.stop();
		}
		catch(Throwable t)
		{
			
		}
		try
		{
			outputStream.close();
		}
		catch(Throwable t)
		{
			
		}
		try
		{
			inputStream.close();
		}
		catch(Throwable t)
		{
			
		}
		try
		{
			socket.close();
		}
		catch(Throwable t)
		{
			
		}
		if(session != null && session.isAlive()) session.close();
		content = null;
		socket = null;
		inputStream = null;
		outputStream = null;
		receiver = null;
		session = null;
		server = null;
	}
	
	/**
	 * <p>사용자로부터 요청을 수신받기 위한 클래스입니다.</p>
	 * 
	 * @author HJOW
	 *
	 */
	class Receiver extends DefaultThread
	{
		byte[] bytes = new byte[bufferSize];
		String reads;
		@Override
		public void onThread()
		{
			if(! isAlive()) return;
			try
			{
				int readLength = inputStream.read(bytes);
				reads = new String(ServerUtil.cut(bytes, readLength));
				
				String responses = prefix + "\n";
				if(content != null)
				{
					if(session == null || (! session.isAlive())) session = server.newSession(socket);
					else session = server.getSession(socket);
					session.setDate(new Date(System.currentTimeMillis()));
					responses = responses + content.content(reads, session);
				}
				else
				{
					responses = responses + "<pre>";
					responses = responses + reads;
					responses = responses + "</pre>";
				}
				outputStream.writeBytes(responses);
			}
			catch(Throwable t)
			{
				t.printStackTrace();
			}
			close();
		}
	}

	public Socket getSocket()
	{
		return socket;
	}

	public void setSocket(Socket socket)
	{
		this.socket = socket;
	}

	public DataOutputStream getOutputStream()
	{
		return outputStream;
	}

	public void setOutputStream(DataOutputStream outputStream)
	{
		this.outputStream = outputStream;
	}

	public DataInputStream getInputStream()
	{
		return inputStream;
	}

	public void setInputStream(DataInputStream inputStream)
	{
		this.inputStream = inputStream;
	}

	public Receiver getReceiver()
	{
		return receiver;
	}

	public void setReceiver(Receiver receiver)
	{
		this.receiver = receiver;
	}

	public PageContent getContent()
	{
		return content;
	}

	public void setContent(PageContent content)
	{
		this.content = content;
	}

	public int getBufferSize()
	{
		return bufferSize;
	}

	public void setBufferSize(int bufferSize)
	{
		this.bufferSize = bufferSize;
	}

	public String getPrefix()
	{
		return prefix;
	}

	public Session getSession()
	{
		return session;
	}

	public void setSession(Session session)
	{
		this.session = session;
	}
}
