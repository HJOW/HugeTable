/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.web.session;

import java.util.Date;
import java.util.Hashtable;
import java.util.Map;

import hjow.web.core.Server;

/**
 * <p>세션을 위한 클래스입니다.</p>
 * 
 * @author HJOW
 *
 */
public class Session
{
	protected Map<String, Object> attributes = new Hashtable<String, Object>();
	protected String ip;
	protected Date date;
	protected transient Server server;
	protected transient boolean alive = true;
	
	/**
	 * <p>세션을 닫습니다.</p>
	 */
	public void close()
	{
		alive = false;
		server = null;
	}
	
	/**
	 * <p>세션이 아직 유효한지 여부를 반환합니다.</p>
	 * 
	 * @return 유효성
	 */
	public boolean isAlive()
	{
		return alive;
	}
	
	public boolean needInvalidate()
	{
		return (System.currentTimeMillis() - date.getTime() >= server.getTimeout());
	}
	
	public void invalidate()
	{
		attributes.clear();
		date = new Date(System.currentTimeMillis());
	}
	
	public Object getAttribute(String key)
	{
		return attributes.get(key);
	}
	
	public void setAttribute(String key, Object value)
	{
		attributes.put(key, value);
	}
	
	public Map<String, Object> getAttributes()
	{
		return attributes;
	}
	public void setAttributes(Map<String, Object> attributes)
	{
		this.attributes = attributes;
	}
	public String getIp()
	{
		return ip;
	}
	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public Date getDate()
	{
		return date;
	}

	public void setDate(Date date)
	{
		this.date = date;
	}
}
