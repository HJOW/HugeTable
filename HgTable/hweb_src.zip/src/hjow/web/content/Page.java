/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.web.content;

import java.util.List;
import java.util.Map;

/**
 * <p>요청에 따라 텍스트를 만들어 반환하는 역할을 하는 페이지 객체입니다.</p>
 * 
 * @author HJOW
 *
 */
public interface Page
{
	/**
	 * <p>매개 변수와 메타 정보들을 받아 텍스트를 반환합니다.</p>
	 * 
	 * @param parameter : 매개 변수들, 요청 URL 뒤 ?KEY1=VALUE1&KEY2=VALUE2 ... 형식
	 * @param meta : 메타 정보들
	 * @return 사용자에게 보낼 텍스트
	 */
	public String process(Map<String, List<String>> parameter, Map<String, String> meta);
	
	/**
	 * <p>페이지를 초기화합니다.</p>
	 */
	public void init();
	
	/**
	 * <p>서버가 중지될 때 호출됩니다.</p>
	 */
	public void close();
	
	/**
	 * <p>이 페이지가 호출되기 위한 명령(요청 URL 값)을 반환합니다.</p>
	 * 
	 * @return 명령 값
	 */
	public String getOrder();
}
