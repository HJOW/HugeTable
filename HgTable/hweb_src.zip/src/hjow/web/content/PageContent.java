/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.web.content;

import hjow.web.session.Session;

/**
 * <p>수신된 요청에 따라 텍스트를 만들어 반환하는 컨텐츠 객체들을 위한 클래스입니다.</p>
 * 
 * @author HJOW
 *
 */
public abstract class PageContent
{
	protected transient boolean initialized = false;
	
	/**
	 * <p>컨텐츠 객체를 초기화합니다.</p>
	 * 
	 */
	public final void initialize()
	{
		if(! initialized) init();
		initialized = true;
	}
	
	/**
	 * <p>텍스트를 만들어 반환합니다.</p>
	 * 
	 * @param gets : 사용자로부터 받은 요청 메시지
	 * @return 보낼 텍스트
	 */
	public abstract String content(String gets, Session session);
	
	/**
	 * <p>컨텐츠 객체를 초기화합니다.</p>
	 * 
	 */
	protected abstract void init();
	
	/**
	 * <p>컨텐츠 객체를 닫습니다.</p>
	 */
	public abstract void close();
}
