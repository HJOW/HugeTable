/*
 
 Copyright 2015 HJOW

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 
 */
package hjow.web.content;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import hjow.web.session.Session;

/**
 * <p>기본적인 페이지 컨텐츠 객체입니다.</p>
 * 
 * @author HJOW
 *
 */
public class DefaultPageContent extends PageContent
{
	protected List<Page> pages = new Vector<Page>();
	protected Page notExistPage;
	
	@Override
	public String content(String gets, Session session)
	{
		StringTokenizer lineTokenizer = new StringTokenizer(gets, "\n");
		StringTokenizer spaceTokenizer;
		int lineIndex = 0;
		Map<String, String> metaData = new Hashtable<String, String>();
		while(lineTokenizer.hasMoreTokens())
		{
			String line = lineTokenizer.nextToken();
			if(lineIndex == 0)
			{
				spaceTokenizer = new StringTokenizer(line, " ");
				String token = spaceTokenizer.nextToken().trim();
				metaData.put("Method", token);
				token = spaceTokenizer.nextToken().trim();
				metaData.put("Order", token);
				token = spaceTokenizer.nextToken().trim();
				metaData.put("Protocol", token);
			}
			else
			{
				spaceTokenizer = new StringTokenizer(line, ":");
				String key = spaceTokenizer.nextToken();
				String value = spaceTokenizer.nextToken().trim();
				metaData.put(key, value);
			}
			
			lineIndex++;
		}
		
		String order = metaData.get("Order");
		if(order.startsWith("/")) order = order.substring(1);
		
		Map<String, List<String>> parameter = new Hashtable<String, List<String>>();
		StringTokenizer paramTokenizer = new StringTokenizer(order, "?");
		order = paramTokenizer.nextToken().trim();
		if(paramTokenizer.hasMoreTokens())
		{
			String left = paramTokenizer.nextToken();
			paramTokenizer = new StringTokenizer(left, "&");
			StringTokenizer equalTokenizer;
			while(paramTokenizer.hasMoreTokens())
			{
				String paramLine = paramTokenizer.nextToken().trim();
				equalTokenizer = new StringTokenizer(paramLine, "=");
				String key = equalTokenizer.nextToken();
				List<String> values = new Vector<String>();
				if(equalTokenizer.hasMoreTokens())
				{
					try
					{
						values.add(URLDecoder.decode(equalTokenizer.nextToken().trim(), "UTF-8"));
					}
					catch (UnsupportedEncodingException e)
					{
						e.printStackTrace();
					}
				}
				if(parameter.get(key) != null) values.addAll(parameter.get(key));
				parameter.put(key, values);
			}
		}
		
		Page page = null;
		for(Page installed : pages)
		{
			if(installed.getOrder() == null) continue;
			if(order.equalsIgnoreCase(installed.getOrder()))
			{
				page = installed;
			}
		}
		if(page == null)
		{
			if(notExistPage != null) return notExistPage.process(parameter, metaData);
			else return "<p>Cannot find the page matched order <b>" + order + "</b></p>";
		}
		
		return page.process(parameter, metaData);
	}

	@Override
	protected void init()
	{
		for(Page page : pages)
		{
			page.init();
		}
	}

	@Override
	public void close()
	{
		for(Page page : pages)
		{
			page.close();
		}
		pages.clear();
	}

	public Page getNotExistPage()
	{
		return notExistPage;
	}

	public void setNotExistPage(Page notExistPage)
	{
		this.notExistPage = notExistPage;
	}

	public List<Page> getPages()
	{
		return pages;
	}

	public void setPages(List<Page> pages)
	{
		this.pages = pages;
	}
}
